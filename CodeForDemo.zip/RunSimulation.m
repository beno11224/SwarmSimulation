function RunSimulation()
    particleSimulation(5);